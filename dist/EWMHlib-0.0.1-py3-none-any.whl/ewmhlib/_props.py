#!/usr/bin/python
# -*- coding: utf-8 -*-

from enum import IntEnum
import Xlib.X


class Props:

    class Root:
        SUPPORTED = "_NET_SUPPORTED"
        CLIENT_LIST = "_NET_CLIENT_LIST"
        CLIENT_LIST_STACKING = "_NET_CLIENT_LIST_STACKING"
        NUMBER_OF_DESKTOPS = "_NET_NUMBER_OF_DESKTOPS"
        DESKTOP_GEOMETRY = "_NET_DESKTOP_GEOMETRY"
        DESKTOP_VIEWPORT = "_NET_DESKTOP_VIEWPORT"
        CURRENT_DESKTOP = "_NET_CURRENT_DESKTOP"
        DESKTOP_NAMES = "_NET_DESKTOP_NAMES"
        ACTIVE = "_NET_ACTIVE_WINDOW"
        WORKAREA = "_NET_WORKAREA"
        SUPPORTING_WM_CHECK = "_NET_SUPPORTING_WM_CHECK"
        VIRTUAL_ROOTS = "_NET_VIRTUAL_ROOTS"
        SHOWING_DESKTOP = "_NET_SHOWING_DESKTOP"
        DESKTOP_LAYOUT = "_NET_DESKTOP_LAYOUT"
        # Additional Root properties (always related to a specific window)
        CLOSE = "_NET_CLOSE_WINDOW"
        MOVERESIZE = "_NET_MOVERESIZE_WINDOW"
        WM_MOVERESIZE = "_NET_WM_MOVERESIZE"
        RESTACK = "_NET_RESTACK_WINDOW"
        REQ_FRAME_EXTENTS = "_NET_REQUEST_FRAME_EXTENTS"
        # WM_PROTOCOLS messages
        PROTOCOLS = "WM_PROTOCOLS"
        PING = "_NET_WM_PING"
        SYNC = "_NET_WM_SYNC_REQUEST"

    class DesktopLayout(IntEnum):
        ORIENTATION_HORZ = 0
        ORIENTATION_VERT = 1
        TOPLEFT = 0
        TOPRIGHT = 1
        BOTTOMRIGHT = 2
        BOTTOMLEFT = 3

    class Window:
        NAME = "_NET_WM_NAME"
        LEGACY_NAME = "WM_NAME"
        VISIBLE_NAME = "_NET_WM_VISIBLE_NAME"
        ICON_NAME = "_NET_WM_ICON_NAME"
        VISIBLE_ICON_NAME = "_NET_WM_VISIBLE_ICON_NAME"
        DESKTOP = "_NET_WM_DESKTOP"
        WM_WINDOW_TYPE = "_NET_WM_WINDOW_TYPE"
        CHANGE_STATE = "WM_CHANGE_STATE"
        WM_STATE = "_NET_WM_STATE"
        ALLOWED_ACTIONS = "_NET_WM_ALLOWED_ACTIONS"
        STRUT = "_NET_WM_STRUT"
        STRUT_PARTIAL = "_NET_WM_STRUT_PARTIAL"
        ICON_GEOMETRY = "_NET_WM_ICON_GEOMETRY"
        ICON = "_NET_WM_ICON"
        PID = "_NET_WM_PID"
        HANDLED_ICONS = "_NET_WM_HANDLED_ICONS"
        USER_TIME = "_NET_WM_USER_TIME"
        FRAME_EXTENTS = "_NET_FRAME_EXTENTS"
        # These are Root properties, but always related to a specific window
        ACTIVE = "_NET_ACTIVE_WINDOW"
        CLOSE = "_NET_CLOSE_WINDOW"
        MOVERESIZE = "_NET_MOVERESIZE_WINDOW"
        WM_MOVERESIZE = "_NET_WM_MOVERESIZE"
        RESTACK = "_NET_RESTACK_WINDOW"
        REQ_FRAME_EXTENTS = "_NET_REQUEST_FRAME_EXTENTS"
        OPAQUE_REGION = "_NET_WM_OPAQUE_REGION"
        BYPASS_COMPOSITOR = "_NET_WM_BYPASS_COMPOSITOR"

    class WindowType:
        DESKTOP = "_NET_WM_WINDOW_TYPE_DESKTOP"
        DOCK = "_NET_WM_WINDOW_TYPE_DOCK"
        TOOLBAR = "_NET_WM_WINDOW_TYPE_TOOLBAR"
        MENU = "_NET_WM_WINDOW_TYPE_MENU"
        UTILITY = "_NET_WM_WINDOW_TYPE_UTILITY"
        SPLASH = "_NET_WM_WINDOW_TYPE_SPLASH"
        DIALOG = "_NET_WM_WINDOW_TYPE_DIALOG"
        NORMAL = "_NET_WM_WINDOW_TYPE_NORMAL"

    class State:
        NULL = "0"
        MODAL = "_NET_WM_STATE_MODAL"
        STICKY = "_NET_WM_STATE_STICKY"
        MAXIMIZED_VERT = "_NET_WM_STATE_MAXIMIZED_VERT"
        MAXIMIZED_HORZ = "_NET_WM_STATE_MAXIMIZED_HORZ"
        SHADED = "_NET_WM_STATE_SHADED"
        SKIP_TASKBAR = "_NET_WM_STATE_SKIP_TASKBAR"
        SKIP_PAGER = "_NET_WM_STATE_SKIP_PAGER"
        HIDDEN = "_NET_WM_STATE_HIDDEN"
        FULLSCREEN = "_NET_WM_STATE_FULLSCREEN"
        ABOVE = "_NET_WM_STATE_ABOVE"
        BELOW = "_NET_WM_STATE_BELOW"
        DEMANDS_ATTENTION = "_NET_WM_STATE_DEMANDS_ATTENTION"
        FOCUSED = "_NET_WM_STATE_FOCUSED"

    class StateAction(IntEnum):
        REMOVE = 0
        ADD = 1
        TOGGLE = 2

    class MoveResize(IntEnum):
        SIZE_TOPLEFT = 0
        SIZE_TOP = 1
        SIZE_TOPRIGHT = 2
        SIZE_RIGHT = 3
        SIZE_BOTTOMRIGHT = 4
        SIZE_BOTTOM = 5
        SIZE_BOTTOMLEFT = 6
        SIZE_LEFT = 7
        MOVE = 8  # movement only
        SIZE_KEYBOARD = 9  # size via keyboard
        MOVE_KEYBOARD = 10  # move via keyboard

    class DataFormat(IntEnum):
        # I guess 16 is not used in Python (no difference between short and long int)
        STR = 8
        INT = 32

    class Mode(IntEnum):
        REPLACE = Xlib.X.PropModeReplace
        APPEND = Xlib.X.PropModeAppend
        PREPEND = Xlib.X.PropModePrepend

    class StackMode(IntEnum):
        ABOVE = Xlib.X.Above
        BELOW = Xlib.X.Below

    class HintAction(IntEnum):
        KEEP = -1
        REMOVE = -2
